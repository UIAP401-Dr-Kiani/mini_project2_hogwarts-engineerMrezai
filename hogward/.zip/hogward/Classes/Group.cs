﻿using System.Collections.Generic;

namespace hogward;

public class Group
{
    protected Type type;
    protected int Score;
    protected List<string> Users;
    protected List<string> Quidditch;
}