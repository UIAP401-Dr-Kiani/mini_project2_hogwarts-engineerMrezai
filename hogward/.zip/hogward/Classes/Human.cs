﻿namespace hogward;

public class Human
{
    public string Name { get; set; } 
    public string Family { get; set; }
    public string DateOfBirth { get; set; }
    public string Father { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    //public BreedType type { get; set; }
    public string Type { get; set; }
    public Gender Gender { get; set; }
    //public string Gender { get; set; }

}

