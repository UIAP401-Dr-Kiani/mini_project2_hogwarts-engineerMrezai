﻿using hogward;

class Drom
{

    string Group { get; set; }
    static int Floor { get; set; } = 4;
    static int Room { get; set; } = 5;
    static int Bed { get; set; } = 3;
    Gender gender { get; set; }

}