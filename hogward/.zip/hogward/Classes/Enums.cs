﻿namespace hogward;

public enum Gender
{
    female, male
}

public enum BreedType
{
    HalfBlood, PureBlood, MuggleBlood
}

public enum Roles
{
    teacher, student
}

public enum Pets
{
    l, rat, cat
}

public enum Type
{
    Hufflepuff, Gryffindor, Ravenclaw, Slytherin
}


